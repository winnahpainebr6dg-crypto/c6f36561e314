// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("snapshot tests\n", stdout);
  return lionss_run_workload("snapshot-tests");
}
