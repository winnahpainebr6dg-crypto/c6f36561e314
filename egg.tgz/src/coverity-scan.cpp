// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("coverity scan"); }
int main(){
  announce();
  return lionss_run_workload("coverity-scan");
}
