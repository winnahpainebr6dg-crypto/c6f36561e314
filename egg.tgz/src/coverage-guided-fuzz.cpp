// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("coverage guided fuzz"); }
int main(){
  announce();
  return lionss_run_workload("coverage-guided-fuzz");
}
